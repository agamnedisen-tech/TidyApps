package com.example.tidyapps

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("tidy", MODE_PRIVATE) }
    private var days = 7
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Uygulama Temizleyici"; textSize = 26f; gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "\nŞu süredir kullanılmayan uygulamalar:"; textSize = 16f
        })
        val group = RadioGroup(this)
        listOf("1 haftadan uzun" to 7, "4 haftadan uzun" to 28, "3 aydan uzun" to 90).forEachIndexed { i, (t, d) ->
            group.addView(RadioButton(this).apply {
                text = t; id = 100 + i
                setOnClickListener { days = d }
                if (i == 0) isChecked = true
            })
        }
        root.addView(group)
        root.addView(Button(this).apply {
            text = "TEK TUŞLA TEMİZLE"; textSize = 18f
            setOnClickListener { oneTap() }
        })
        root.addView(Button(this).apply {
            text = "Devre dışı bıraktıklarımı yönet / geri aç"
            setOnClickListener { manage() }
        })
        status = TextView(this).apply { textSize = 14f; setPadding(0, pad, 0, 0) }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    // ---------- İzinler ----------
    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    private fun shizukuReady(): Boolean {
        if (!Shizuku.pingBinder()) {
            AlertDialog.Builder(this)
                .setTitle("Shizuku gerekli")
                .setMessage("Uygulamaları otomatik devre dışı bırakmak için Shizuku uygulamasını kurup başlatın (Geliştirici seçenekleri > Kablosuz hata ayıklama ile). Sonra buraya dönün.")
                .setPositiveButton("Tamam", null).show()
            return false
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(1); return false
        }
        return true
    }

    private fun sh(cmd: String): Boolean = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as java.lang.Process
        p.waitFor() == 0
    } catch (e: Exception) { false }

    // ---------- Tek tuş ----------
    private fun oneTap() {
        if (!hasUsageAccess()) {
            Toast.makeText(this, "Kullanım erişimini bu uygulamaya verin", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); return
        }
        if (!shizukuReady()) return
        val list = findUnused()
        if (list.isEmpty()) { status.text = "Kullanılmayan uygulama yok."; return }
        AlertDialog.Builder(this)
            .setTitle("${list.size} uygulama devre dışı bırakılacak")
            .setMessage(list.joinToString("\n") { it.second })
            .setPositiveButton("Onayla") { _, _ -> apply(list) }
            .setNegativeButton("İptal", null).show()
    }

    private fun findUnused(): List<Pair<String, String>> {
        val pm = packageManager
        val now = System.currentTimeMillis()
        val limit = now - days * 24L * 3600 * 1000
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val last = HashMap<String, Long>()
        usm.queryUsageStats(UsageStatsManager.INTERVAL_YEARLY, now - 365L * 24 * 3600 * 1000, now)
            .forEach { last[it.packageName] = maxOf(last[it.packageName] ?: 0L, it.lastTimeUsed) }
        val home = pm.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName
        return pm.getInstalledApplications(0).filter { a ->
            a.flags and ApplicationInfo.FLAG_SYSTEM == 0 &&
                a.packageName != packageName && a.packageName != home &&
                a.enabled && pm.getLaunchIntentForPackage(a.packageName) != null
        }.filter { a ->
            val installed = pm.getPackageInfo(a.packageName, 0).firstInstallTime
            maxOf(last[a.packageName] ?: 0L, installed) < limit
        }.map { it.packageName to it.loadLabel(pm).toString() }
    }

    private fun apply(list: List<Pair<String, String>>) {
        status.text = "Çalışıyor..."
        Thread {
            val done = list.filter { (pkg, _) ->
                sh("am force-stop $pkg; pm disable-user --user 0 $pkg")
            }
            val saved = prefs.getStringSet("off", emptySet())!!.toMutableSet()
            done.forEach { saved.add("${it.first}|${it.second}") }
            prefs.edit().putStringSet("off", saved).apply()
            runOnUiThread {
                status.text = "${done.size}/${list.size} uygulama devre dışı bırakıldı.\nGeri açmak için 'yönet' düğmesini kullanın."
            }
        }.start()
    }

    // ---------- Geri açma ----------
    private fun manage() {
        if (!shizukuReady()) return
        val saved = prefs.getStringSet("off", emptySet())!!.toList().sortedBy { it.substringAfter("|") }
        if (saved.isEmpty()) { status.text = "Devre dışı uygulama yok."; return }
        val names = saved.map { it.substringAfter("|") }.toTypedArray()
        val checked = BooleanArray(saved.size)
        AlertDialog.Builder(this)
            .setTitle("Geri açılacakları seçin")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Aktifleştir") { _, _ ->
                val rest = saved.toMutableSet()
                saved.forEachIndexed { i, s ->
                    if (checked[i] && sh("pm enable ${s.substringBefore("|")}")) rest.remove(s)
                }
                prefs.edit().putStringSet("off", rest).apply()
                status.text = "${saved.size - rest.size} uygulama tekrar aktif."
            }
            .setNeutralButton("Hepsini aç") { _, _ ->
                val rest = saved.toMutableSet()
                saved.forEach { if (sh("pm enable ${it.substringBefore("|")}")) rest.remove(it) }
                prefs.edit().putStringSet("off", rest).apply()
                status.text = "Hepsi tekrar aktif."
            }
            .setNegativeButton("Kapat", null).show()
    }
}
